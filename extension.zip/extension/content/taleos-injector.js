/**
 * Taleos - Content Script (site Taleos)
 * Intercepte le clic sur "Candidater" et envoie à l'extension pour ouverture + automatisation
 * Synchronise aussi l'auth depuis le site vers l'extension (connexion automatique)
 */

(function() {
  'use strict';
  if (window.__taleosInjectorLoaded) return;
  window.__taleosInjectorLoaded = true;
  try { document.documentElement.setAttribute('data-taleos-injector', 'ready'); } catch (_) {}

  function syncAuthFromPage(forceRefresh) {
    try {
      if (!chrome?.runtime?.id) return;
      chrome.runtime.sendMessage({ action: 'inject_auth_sync', forceRefresh: !!forceRefresh }).catch(function() {});
    } catch (_) {}
  }

  function isExtensionValid() {
    try { return !!chrome?.runtime?.id; } catch (_) { return false; }
  }

  window.addEventListener('__TALEOS_AUTH_SYNC__', function(e) {
    const { token, uid, email } = e.detail || {};
    if (token && uid) {
      chrome.runtime.sendMessage({
        action: 'sync_auth_from_site',
        taleosUserId: uid,
        taleosIdToken: token,
        taleosUserEmail: email || ''
      }).catch(function() {});
    }
  });

  function scheduleSync() {
    syncAuthFromPage(false);
    setTimeout(function() { syncAuthFromPage(true); }, 2500);
    setTimeout(function() { syncAuthFromPage(true); }, 6000);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleSync);
  } else {
    scheduleSync();
  }
  window.addEventListener('pageshow', function(ev) {
    if (ev.persisted) {
      scheduleSync();
    }
  });

  let lastHealthCheck = 0;
  const HEALTH_CHECK_INTERVAL = 90000;
  const HEALTH_CHECK_RETRY_DELAY = 1500;
  const HEALTH_CHECK_RETRIES = 3;
  function isContextInvalidated(err) {
    const msg = (err?.message || String(err)).toLowerCase();
    return /context invalidated|extension.*invalid/i.test(msg);
  }

  function isReceivingEndMissing(err) {
    const msg = (err?.message || String(err)).toLowerCase();
    return /receiving end does not exist/i.test(msg);
  }
  function showReloadToast() {
    const toast = document.createElement('div');
    toast.textContent = 'Extension déconnectée. Rechargement de la page...';
    Object.assign(toast.style, {
      position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)', zIndex: 2147483647,
      background: '#dc2626', color: '#fff', padding: '12px 24px', borderRadius: '8px', fontSize: '14px',
      fontFamily: 'sans-serif', boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
    });
    document.body.appendChild(toast);
    setTimeout(function() { window.location.reload(); }, 2000);
  }
  async function healthCheck() {
    if (Date.now() - lastHealthCheck < HEALTH_CHECK_INTERVAL) return;
    lastHealthCheck = Date.now();
    for (let i = 0; i < HEALTH_CHECK_RETRIES; i++) {
      try {
        await chrome.runtime.sendMessage({ action: 'ping' });
        syncAuthFromPage(true);
        return;
      } catch (e) {
        const invalidated = isContextInvalidated(e);
        const receivingEnd = isReceivingEndMissing(e);
        if (invalidated || receivingEnd) {
          showReloadToast();
          return;
        }
        if (i < HEALTH_CHECK_RETRIES - 1) {
          await new Promise(function(r) { setTimeout(r, HEALTH_CHECK_RETRY_DELAY); });
          continue;
        }
      }
    }
  }
  document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
      setTimeout(healthCheck, 2000);
    }
  });
  setInterval(healthCheck, HEALTH_CHECK_INTERVAL);

  function getBankIdFromUrl(url) {
    if (!url) return null;
    const lowerUrl = String(url).toLowerCase();
    if (lowerUrl.includes('groupecreditagricole.jobs') || lowerUrl.includes('creditagricole')) return 'credit_agricole';
    if (lowerUrl.includes('careers.societegenerale.com') || lowerUrl.includes('societegenerale') || lowerUrl.includes('socgen.taleo.net')) return 'societe_generale';
    if (lowerUrl.includes('deloitte.com') || (lowerUrl.includes('myworkdayjobs.com') && lowerUrl.includes('deloitte'))) return 'deloitte';
    if (lowerUrl.includes('recrutement.bpce.fr')) return 'bpce';
    if (lowerUrl.includes('careers.axa.com') || lowerUrl.includes('axa.com/careers-home') || lowerUrl.includes('icims.com/jobs/') || lowerUrl.includes('icims.eu/jobs/')) return 'axa';
    return null;
  }

  function getBankIdFromCompanyName(companyName) {
    const normalized = String(companyName || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (!normalized) return null;
    if (normalized.includes('credit agricole') || normalized.includes('crédit agricole') || normalized.includes('amundi') || normalized.includes('lcl') || normalized.includes('bforbank') || normalized.includes('caceis') || normalized.includes('indosuez') || normalized.includes('idia')) return 'credit_agricole';
    if (normalized.includes('societe generale') || normalized.includes('société générale')) return 'societe_generale';
    if (normalized.includes('deloitte')) return 'deloitte';
    if (normalized.includes('bpce')) return 'bpce';
    if (normalized.startsWith('axa') || normalized.includes(' groupe axa') || normalized.includes(' gie axa') || normalized.includes('direct assurance')) return 'axa';
    return null;
  }

  function getAxaApplyUrl(jobUrl) {
    const match = String(jobUrl || '').match(/\/jobs\/(\d+)(?:[/?#]|$)/i);
    if (!match) return jobUrl;
    return `https://careers-fr-axa.icims.com/jobs/${match[1]}/login`;
  }

  function findJobCard(el) {
    let node = el;
    while (node && node !== document.body) {
      const url = node.getAttribute?.('data-job-url');
      if (url) return { card: node, jobUrl: url };
      node = node.parentElement;
    }
    // Fallback : chercher le lien "Voir l'offre" à côté du bouton
    const actions = el.closest?.('.job-actions, .job-footer');
    const link = actions?.querySelector?.('a.job-link[href]');
    if (link?.href) {
      const card = actions?.closest?.('.job-card') || actions?.parentElement?.closest?.('.job-card') || actions;
      return { card, jobUrl: link.href };
    }
    return null;
  }

  function extractJobIdFromOnClick(btn) {
    const onclick = btn.getAttribute?.('onclick') || '';
    const m = onclick.match(/applyToJob\s*\(\s*['"]([^'"]+)['"]/);
    return m ? m[1] : null;
  }

  // Anti-spam + retry : empêcher les clics multiples, permettre retry si échec
  const COOLDOWN_MS = 2500;
  const FAILURE_TIMEOUT_MS = 4 * 60 * 1000;
  const processingJobs = new Map();

  function clearProcessing(jobId, reEnableButton) {
    const entry = processingJobs.get(jobId);
    if (entry) {
      if (entry.timeoutId) clearTimeout(entry.timeoutId);
      processingJobs.delete(jobId);
      if (reEnableButton && entry.btn && entry.btn.isConnected) {
        entry.btn.disabled = false;
        entry.btn.removeAttribute('data-taleos-processing');
        const orig = entry.btn.getAttribute('data-taleos-original-text');
        if (orig) entry.btn.textContent = orig;
      }
    }
  }

  function showProfileIncompletePopup(missingFields) {
    const msg = missingFields && missingFields.length > 0
      ? 'Votre profil est incomplet. Veuillez compléter toutes les informations requises dans Mon profil avant de lancer une candidature : ' + missingFields.join(', ')
      : 'Votre profil est incomplet. Complétez toutes les informations requises dans Mon profil avant de lancer une candidature.';

    // Créer la modale directement en DOM (évite CSP qui bloque l'injection de script inline)
    const existing = document.getElementById('taleos-profile-incomplete-modal');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'taleos-profile-incomplete-modal';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-labelledby', 'taleos-profile-incomplete-title');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:2147483647;font-family:system-ui,-apple-system,sans-serif';

    const box = document.createElement('div');
    box.style.cssText = 'background:#fff;padding:24px;border-radius:12px;max-width:450px;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.2)';

    const title = document.createElement('h3');
    title.id = 'taleos-profile-incomplete-title';
    title.textContent = 'Profil incomplet';
    title.style.cssText = 'margin:0 0 16px;font-size:18px;color:#1f2937';

    const text = document.createElement('p');
    text.textContent = msg;
    text.style.cssText = 'margin:0 0 20px;font-size:14px;line-height:1.5;color:#4b5563';

    const btnProfile = document.createElement('button');
    btnProfile.textContent = 'Compléter mon profil';
    btnProfile.style.cssText = 'margin:8px;padding:10px 20px;background:#667eea;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px';

    const btnClose = document.createElement('button');
    btnClose.textContent = 'Fermer';
    btnClose.style.cssText = 'margin:8px;padding:10px 20px;background:#f3f4f6;border:none;border-radius:8px;cursor:pointer;font-size:14px;color:#374151';

    box.appendChild(title);
    box.appendChild(text);
    box.appendChild(btnProfile);
    box.appendChild(btnClose);
    overlay.appendChild(box);

    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) overlay.remove();
    });
    btnProfile.addEventListener('click', function() {
      overlay.remove();
      window.location.href = new URL('profile.html', window.location.href).href;
    });
    btnClose.addEventListener('click', function() {
      overlay.remove();
    });

    document.body.appendChild(overlay);
  }

  function setButtonProcessing(btn, jobId) {
    if (!btn.dataset.taleosOriginalText) btn.dataset.taleosOriginalText = btn.textContent || '📝 Candidater';
    btn.textContent = '⏳ En cours...';
    btn.disabled = true;
    btn.dataset.taleosProcessing = '1';
    btn.setAttribute('data-taleos-processing', '1');
    const timeoutId = setTimeout(function() {
      clearProcessing(jobId, true);
    }, FAILURE_TIMEOUT_MS);
    processingJobs.set(jobId, { btn, timestamp: Date.now(), timeoutId });
  }

  async function onApplyClick(e) {
    const btn = e.target.closest?.('.job-apply-btn');
    if (!btn) return;

    const found = findJobCard(btn);
    if (!found) return;

    const { card, jobUrl } = found;
    const jobId = extractJobIdFromOnClick(btn) || (card.querySelector('.job-id')?.textContent || '').trim();
    const jobTitle = (card.querySelector('.job-title')?.textContent || '').trim();
    const companyName = (card.querySelector('.company-name-wrapper span, .job-company span')?.textContent || '').trim();
    let bankId = getBankIdFromUrl(jobUrl);
    if (jobUrl && String(jobUrl).toLowerCase().includes('groupecreditagricole.jobs')) {
      bankId = 'credit_agricole';
    }
    if (!bankId) bankId = getBankIdFromCompanyName(companyName);

    if (!jobId) return;

    const now = Date.now();
    const entry = processingJobs.get(jobId);
    if (entry) {
      if (now - entry.timestamp < COOLDOWN_MS) return;
      clearProcessing(jobId, false);
    }

    if (!isExtensionValid()) {
      showReloadToast();
      return;
    }

    // Bloquer immédiatement le clic (sync) pour éviter le double onglet page + extension
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    // Marquer tout de suite pour que la page (si elle reçoit l’événement) n’ouvre pas d’onglet
    btn.dataset.taleosProcessing = '1';
    btn.setAttribute('data-taleos-processing', '1');

    // Ping rapide : uniquement pour réveiller le service worker si besoin, mais on ne bloque plus l'automatisation sur un timeout
    try {
      await Promise.race([
        chrome.runtime.sendMessage({ action: 'ping' }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('ping_timeout')), 1500))
      ]);
    } catch (e) {
      console.warn('[Taleos] Ping extension en échec ou timeout:', e?.message || e);
      if (isContextInvalidated(e) || isReceivingEndMissing(e)) {
        showReloadToast();
        return;
      }
      // Sinon on tente quand même la suite.
    }

    try {
      const checkPromise = chrome.runtime.sendMessage({ action: 'taleos_check_profile_complete', bankId });
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 6000));
      const checkRes = await Promise.race([checkPromise, timeoutPromise]);
      if (!checkRes || checkRes.complete !== true) {
        delete btn.dataset.taleosProcessing;
        btn.removeAttribute('data-taleos-processing');
        showProfileIncompletePopup(checkRes?.missingFields || []);
        return;
      }
    } catch (err) {
      console.warn('[Taleos] Vérification profil:', err);
      delete btn.dataset.taleosProcessing;
      btn.removeAttribute('data-taleos-processing');
      if (isContextInvalidated(err) || isReceivingEndMissing(err)) {
        showReloadToast();
        return;
      }
      showProfileIncompletePopup([]);
      return;
    }

    setButtonProcessing(btn, jobId);
    syncAuthFromPage(true);

    const openUrl = (bankId === 'credit_agricole' || jobUrl.includes('groupecreditagricole.jobs'))
      ? 'https://groupecreditagricole.jobs/fr/connexion/'
      : (bankId === 'axa' ? getAxaApplyUrl(jobUrl) : jobUrl);

    const fallbackOpen = () => {
      clearProcessing(jobId, true);
      if (bankId === 'societe_generale' || jobUrl.includes('careers.societegenerale.com') || jobUrl.includes('socgen.taleo.net')) {
        chrome.storage.local.set({
          taleos_apply_fallback: {
            offerUrl: jobUrl,
            bankId,
            jobId,
            jobTitle,
            companyName,
            timestamp: Date.now()
          }
        });
      }
      if (bankId === 'bpce' || jobUrl.includes('recrutement.bpce.fr')) {
        chrome.storage.local.set({
          taleos_apply_fallback: {
            offerUrl: jobUrl,
            bankId,
            jobId,
            jobTitle,
            companyName,
            timestamp: Date.now()
          }
        });
      }
      window.open(openUrl, '_blank');
    };

    async function tryApply() {
      await chrome.runtime.sendMessage({ action: 'ping' }).catch(() => {});
      return Promise.race([
        chrome.runtime.sendMessage({
          action: 'taleos_apply',
          offerUrl: jobUrl,
          bankId,
          jobId,
          jobTitle,
          companyName
        }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 12000))
      ]);
    }
    try {
      let response;
      try {
        response = await tryApply();
      } catch (firstErr) {
        if (!/timeout/i.test(firstErr?.message || '')) throw firstErr;
        await new Promise(r => setTimeout(r, 2000));
        response = await tryApply();
      }
      if (response?.error) {
        console.warn('[Taleos] handleApply:', response.error);
        if (/profil incomplet|profil introuvable/i.test(response.error)) {
          clearProcessing(jobId, true);
          const match = response.error.match(/avant de lancer une candidature[:\s]+(.+)$/);
          const missingFields = match ? match[1].split(',').map(m => m.trim()).filter(Boolean) : [];
          showProfileIncompletePopup(missingFields.length ? missingFields : []);
        } else {
          fallbackOpen();
        }
      }
    } catch (err) {
      const msg = (err?.message || String(err)).toLowerCase();
      const contextInvalidated = isContextInvalidated(err);
      if (contextInvalidated) {
        clearProcessing(jobId, true);
        const toast = document.createElement('div');
        toast.textContent = 'Extension déconnectée. Rechargement de la page...';
        Object.assign(toast.style, {
          position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)', zIndex: 2147483647,
          background: '#dc2626', color: '#fff', padding: '12px 24px', borderRadius: '8px', fontSize: '14px',
          fontFamily: 'sans-serif', boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
        });
        document.body.appendChild(toast);
        setTimeout(function() { window.location.reload(); }, 2000);
        return;
      }
      console.warn('[Taleos] Extension non disponible ou timeout — ouverture manuelle:', err?.message || err);
      fallbackOpen();
    }
  }

  document.addEventListener('click', onApplyClick, true);

  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.action === 'taleos_candidature_success') {
      clearProcessing(msg.jobId || '', false);
      window.dispatchEvent(new CustomEvent('taleos-extension-candidature-success', {
        detail: { jobId: msg.jobId, status: msg.status }
      }));
    }
    if (msg.action === 'taleos_candidature_failure') {
      clearProcessing(msg.jobId || '', true);
      window.dispatchEvent(new CustomEvent('taleos-extension-candidature-failure', {
        detail: { jobId: msg.jobId, error: msg.error }
      }));
    }
    if (msg.action === 'taleos_request_auth') {
      syncAuthFromPage(true);
    }
    if (msg.action === 'taleos_auth_required') {
      window.dispatchEvent(new CustomEvent('taleos-extension-auth-required'));
    }
    if (msg.action === 'taleos_offer_unavailable') {
      clearProcessing(msg.jobId || '', true);
      window.dispatchEvent(new CustomEvent('taleos-extension-offer-unavailable', {
        detail: { jobId: msg.jobId, jobTitle: msg.jobTitle }
      }));
    }
  });

  window.addEventListener('taleos-request-test-connection', function(e) {
    const d = e.detail || {};
    if (!d.bankId || !d.email || !d.firebaseUserId) return;
    chrome.runtime.sendMessage({
      action: 'test_connection',
      bankId: d.bankId,
      email: d.email,
      password: d.password || '',
      firebaseUserId: d.firebaseUserId,
      bankName: d.bankName
    }).then(function(res) {
      window.dispatchEvent(new CustomEvent('taleos-test-connection-result', {
        detail: res || {}
      }));
    }).catch(function(err) {
      window.dispatchEvent(new CustomEvent('taleos-test-connection-result', {
        detail: { success: false, message: err?.message || 'Extension non disponible' }
      }));
    });
  });
})();
